buttonX = 100
buttonY = 100

minimFinestraX = 300
minimFinestraY = 100

normalFinestraX = 1200
normalFinestraY = 700

maximFinestraX = 1920
maximFinestraY = 1080